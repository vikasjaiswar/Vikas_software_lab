export default class RuntimeConstants {
    static readonly system: string = "system";
    static readonly osName: string = "os_name";
    static readonly Windows: string = "Windows";
    static readonly Unix: string = "Unix";
}